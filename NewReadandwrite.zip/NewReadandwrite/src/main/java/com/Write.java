package com;

import java.io.File;
import java.io.IOException;

public class Write {

    public void mywrite(double[] data,long fq) throws IOException, WavFileException {
        long numFrames=data.length;
        int sampleRate =(int) fq;

        WavFile wavFile = WavFile.newWavFile(new File("/home/gopal/Desktop/G2020-01-26 13:12:45.wav"), 2, numFrames, 16, sampleRate);

        double[][] buffer = new double[2][100];

        // Initialise a local frame counter
        long frameCounter = 0;
        int c=-1;

        // Loop until all frames written
        while (frameCounter < numFrames)
        {
            // Determine how many frames to write, up to a maximum of the buffer size
            long remaining = wavFile.getFramesRemaining();
            int toWrite = (remaining > 100) ? 100 : (int) remaining;

            // Fill the buffer, one tone per channel
            for (int s=0 ; s<toWrite ; s++, frameCounter++)
            { c=c+1;
                buffer[0][s] =  data[c]; //Math.sin(2.0 * Math.PI * 400 * frameCounter / sampleRate);
                buffer[1][s] = data[c];  // Math.sin(2.0 * Math.PI * 500 * frameCounter / sampleRate);
            }

            // Write the buffer
            wavFile.writeFrames(buffer, toWrite);
        }
        // Close the wavFile
        wavFile.close();
        System.out.println("done");
    }
}

