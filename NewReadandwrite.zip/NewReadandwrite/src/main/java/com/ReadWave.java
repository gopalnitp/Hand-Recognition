package com;

import java.io.File;

public class ReadWave {

    public static void main(String[] args)
    {
        try
        {
            // Open the wav file specified as the first argument
            WavFile wavFile = WavFile.openWavFile(new File("/home/gopal/Desktop/2020-01-26 13:12:45.wav"));


            // Display information about the wav file
            wavFile.display();
             long numFrames=wavFile.getNumFrames();
             long sampleRate = wavFile.getSampleRate();

             double[] data=new double[(int) numFrames];

            // Get the number of audio channels in the wav file
            int numChannels = wavFile.getNumChannels();

            // Create a buffer of 100 frames
            double[] buffer = new double[100 * numChannels];

            int framesRead;
            double min = Double.MAX_VALUE;
            double max = Double.MIN_VALUE;
            int c=-1;

            do
            {
                // Read frames into buffer
                framesRead = wavFile.readFrames(buffer, 100);

                // Loop through frames and look for minimum and maximum value
                for (int s=0 ; s<framesRead * numChannels ; s++)
                {  c=c+1;
                    data[c]=buffer[s];
                    if (buffer[s] > max) max = buffer[s];
                    if (buffer[s] < min) min = buffer[s];
                }
            }
            while (framesRead != 0);

            // Close the wavFile
            wavFile.close();

            // Output the minimum and maximum value
            System.out.printf("Min: %f, Max: %f\n", min, max);
            System.out.printf(String.valueOf(data.length));
            Write write=new Write();
            write.mywrite(data,sampleRate);

        }
        catch (Exception e)
        {
            System.err.println(e);
        }
    }



}
